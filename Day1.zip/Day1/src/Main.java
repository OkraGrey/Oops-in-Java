import java.util.Date;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {



        Employee e = new Employee("Hasnain",100000,10);






//        Every object is inherited from Object class which carrys along some basic functions
//                like toString. We just overrided that function.

        System.out.println(e);












//        e.setAge(-10);

        //ASSIGNMENT:
        //CLass USER
        //ATTRIBUTES
        //name, id, paswword, age, username,DOB,secutrity quesiton,,secAnswer, Summary
        //Related Getters and Setters, COnstructors
        // TOSTRING









        //        System.out.println("Hello world!");
//    Employee e = new Employee();
//     e.SetName("usama");
////    System.out.println(e.GetName());
//
//    Employee e1 = new Employee("usama",1000000000,20);
//    int a =10;
//    int b =20;
//    a=b;
//        System.out.println(a);
//        System.out.println(b);
//        a=40;
//        System.out.println(a);
//        System.out.println(b);

//
//
//    Employee e2 = new Employee(e1);
//    e2.SetName("Hasnain");
//        System.out.println(e1.GetName());
//        System.out.println(e2.GetName());
//
//

//    e.greetings();
//    e.name = "Usama";
//    e.age=-10;
//    e.salary=-100;
//    System.out.println("age = "+ e.age+" salary = "+e.salary+" name  = "+e.name);
//        System.out.println("Hello " + e.name);
//        System.out.println(e); //toString

    }
}











//paradigms way of programming
//functional , sequential , object oriented paradigm
//Reusable

//Basic Pillars of OOP
//Abstraction
//Inheritance
//Encapsualation
//Polymorphism
