import java.util.Date;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {

        User u = new User(1, "Hasnain", "P#203", "abc@gmail.com", "pass");
        u.Greetings();
        u.Greetings(1, "abv");
        u.Greetings(1, "dfhdh0", "Dhfdfhdf");
        u.Greetings("asfa", 5);


//paradigms way of programming
//functional , sequential , object oriented paradigm
//Reusable

//Basic Pillars of OOP
//Abstraction
//Inheritance
//Encapsualation
//Polymorphism
    }}