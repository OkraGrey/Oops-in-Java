public class City {
    private String Name;
    private String Province;
    private String cityCode;
    private Country country;

    public String getName() {
        return Name;
    }

    public String getProvince() {
        return Province;
    }

    public String getCityCode() {
        return cityCode;
    }

    public Country getCountry() {
        return country;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setProvince(String province) {
        Province = province;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "City{" +
                "Name='" + Name + '\'' +
                ", Province='" + Province + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", country=" + country +
                '}';
    }
}
