public class Country {
    private String Name;
    private int code;
}
