public abstract class Product {
    //can have abstract and non abstract elements
    //does not have a constructor
    // cannot create an object
    // only inherited

    private String Name;
    private String Genre;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    //Method Enforcement
    public abstract void mehtod1();//No body
    public void abc(){}
}
