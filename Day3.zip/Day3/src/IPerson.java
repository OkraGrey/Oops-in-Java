public interface IPerson {
    //Already abstract
    //attributes final

    //Methods

    public void GetAge();
    public void GetANYTHING();

}
