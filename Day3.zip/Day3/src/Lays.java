public class Lays extends Product{
    @Override
    public void mehtod1() {
        //Method Enforce
    }
}
