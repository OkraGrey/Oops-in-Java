public class Student extends Person{
    private int rollNo;
    private String Institute;

    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getInstitute() {
        return Institute;
    }

    public void setInstitute(String institute) {
        Institute = institute;
    }

    @Override
    public void Greetings(){
        System.out.println("Hi this is child");
    }


    @Override
    public String toString() {
        return super.toString()+"Student{" +
                "rollNo=" + rollNo +
                ", Institute='" + Institute + '\'' +
                '}';
    }
}
