public class Employee {
  //class-level-attributes
  //Access Modifiers
    //Encapsulation

    private String name;
    private int age;
    private int salary;

    //Constructor: A special type of method
    //->Name will be same as the class
    //There can be more than 1 constuctors with different method SIGNATURE.
    //Always have public access modifier
    //Every class has a built in constructtor with 0 parameters which vanishes when u create your own
    //Copy Constructor
    public Employee(){

    }
    public Employee(Employee e1) {
        this.name=e1.name;
        this.age=e1.age;
        this.salary=e1.salary;
    }//COPY CONSTRUCTOR

//    public Employee Employee(Employee e){
//        this.name=e.name;
//        this.age=e.age;
//        this.salary=e.salary;
//        return this;
//    }
    public Employee(String name,int salary,int age){
        this.name=name;
        this.salary=salary;
        this.age=age;
    }

    // Getters

    public String GetName(){
        return this.name;
    }

    public int getAge() {
        return age;
    }

    public int getSalary() {
        return salary;
    }
    //Setters

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        while (age<=0){
        this.age = age;
        }

    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void SetName(String name){
        this.name=name;
    }



    void greetings(){
        System.out.println("Hello Usama");
    }

    public String toString(){
        return "Name = "+this.name + " Age = "+this.age +" Salary = "+this.salary;
    }

    //function defined within a class are called methods.
}
//Class = Template
//Registration Form
// Name, fname, address, number , cnic
// Object

// Data Types
// Primitive Abstract Data Types
//int, string, float, decimal built in types => primitive
// Abstract data types = user defined data types
//How to make abstract data types
//1-enum
//2-class
//3-interface
//4-struct
//5-record

//private, public, protected



//salary =100
//tax =17percent
//getTax ret 100*(0.17)

//Getters and Setters
//Methods



// Object Initialization
