public class Country {
    private String Name;
    private int code;

    public String getName() {
        return Name;
    }

    public Country(String name, int code) {
        Name = name;
        this.code = code;
    }
    public Country(){

    }

    public void setName(String name) {
        Name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "Country{" +
                "Name='" + Name + '\'' +
                ", code=" + code +
                '}';
    }
}
