import java.util.Date;

public class User {
    //FIELDS
    //Object specific or class specific?
    //Static fields can be called in static methods or static constructors only
    //Non Static can call static and non-static fiedls(both)
    private static int count =0; //Static Members are class level / shared field
    private int id;
    private String Name;
    private String Address;
    private String UserName;
//    private Date DOB;
    private String Password;

    //Constructor
    //parameterLess

    public User(){
        count++;
    }
    public User(int id, String name){
        this();
        this.id=id;
        this.Name=name;
        System.out.println("Smaller is called");
    }
    public User(int id, String name,String address,String username,String password){
        this(id,name);
        System.out.println("Big Constructor is called");
            this.Address=address;
            this.Password=password;
            this.UserName=username;
    }
    //We are calling one constructor within another constructor without making an object

    public static int getCount() {
        return count;
    }

    //Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getUserName() {
        return UserName;
    }

    public String getPassword() {
        return Password;
    }

    //Setters


    public static void setCount(int count) {
        User.count = count;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public void setPassword(String password) {
        Password = password;
    }

    //METHODS

    //What is Signature of Method?
    //Name, # of Parameters, Order of Parameters
//
    void Greetings(){
        System.out.println("No Params");
    }
    void Greetings(int a, String b){
        System.out.println(a+" " +b);
    }
    void Greetings(int a , String b ,String c){
        System.out.println(a+" "+b+" "+c);
    }
    void Greetings(String a, int b){
        System.out.println(a+" "+b);
    }



    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", Name='" + Name + '\'' +
                ", Address='" + Address + '\'' +
                ", UserName='" + UserName + '\'' +
                ", Password='" + Password + '\'' +
                '}';
    }
}
