import java.util.Date;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {

        //Inheritance
        // is a relation
        //parent child relation
        //In java , there can be only one parent
        //Multiple inheritance is not allowed
        //Multi level inheritance can be achieved.
        Person p = new Person();
        Student s = new Student();
//        System.out.println(s);
        s.Greetings();














        //Association
            //Composition
//        Country pak= new Country();
//        pak.setName("Pakistan");
//        pak.setCode(92);

//        City lhr = new City();
//        lhr.setName("Lahore");
//        lhr.setCountry(new Country("Pakistan",92));
//        lhr.setCityCode("042");
//        lhr.setProvince("Punjab");
//
//        System.out.println(lhr);


        // Complex types as attributes of one class















//        User u = new User(1, "Hasnain", "P#203", "abc@gmail.com", "pass");
//        u.Greetings();
//        u.Greetings(1, "abv");
//        u.Greetings(1, "dfhdh0", "Dhfdfhdf");
//        u.Greetings("asfa", 5);


//paradigms way of programming
//functional , sequential , object oriented paradigm
//Reusable

//Basic Pillars of OOP
//Abstraction
//Inheritance
//Encapsualation
//Polymorphism
    }}